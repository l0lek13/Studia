package com.company.Klasy;

import com.sun.scenario.effect.impl.prism.PrReflectionPeer;

import java.util.List;

public class Graf {
    List<Przejscie> lista;

    public Graf(List<Przejscie> _list) {
        lista = _list;


    }
    public Graf() {

    }

    public int maxDestination(){
        int i=0;
        int max =0;
        int numeri =0;
        for(Przejscie x : lista)
        {
            if(i==0){
                max = x.destination;

            }
            if (x.destination >max)
            {

                max = x.destination;
                numeri = i;
            }
            i++;
        }

        System.out.println("max" + max);
        return max;
    }
    public void szukaj(){
        int max =maxDestination();


    }


}
