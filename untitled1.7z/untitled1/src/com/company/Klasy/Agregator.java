package com.company.Klasy;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;

    public class Agregator {
//public List<Przejscie> lista;
public Agregator(File file) throws FileNotFoundException {
    //Agregator agregator = new Agregator();

    Scanner in = new Scanner(file);
    String word = in.nextLine();
    //List<Przejscie> lista = null;
    List<Przejscie> lista = new ArrayList<Przejscie>();
    while(!word.isEmpty()) {

        int length = word.length();
        String vartoscNow ="";
        char litera ;
        String []tablica = new String[6] ;
        int licznikTablica =0;
        for (int i = 0; i < length; i++) {
            litera =word.charAt(i);
            if(litera != ';') {
                System.out.print(litera);
                vartoscNow = vartoscNow + litera;
            }else{

                tablica[licznikTablica] = vartoscNow;
                licznikTablica++;
                vartoscNow = "";
            }
        }
        ///////delaracja przejsca
        System.out.print("litera");
        int var1 =Integer.parseInt(tablica[0]);
        int var2 =Integer.parseInt(tablica[1]);
        double var3 =Double.parseDouble(tablica[2]);
        double var4 =Double.parseDouble(tablica[3]);
        double var5 =Double.parseDouble(tablica[4]);
        Przejscie przejscie = new Przejscie(var1,var2,var3,var4,var5);

        lista.add(przejscie);


        System.out.println("\n");
        if (in.hasNextLine()){
        word = in.nextLine();}
        else{
            break;
        }
    }
    System.out.println(lista);
    Graf graf = new Graf(lista);
    graf.szukaj();

}

}
