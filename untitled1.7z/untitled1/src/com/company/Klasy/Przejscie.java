package com.company.Klasy;

public class Przejscie {
    public int source;
    public int destination;
    public double timeOptimistic;
    public double timePesymistic;
    public double timeAvreg;
    public double timeEstimated;

    public Przejscie(int _source, int _destination, double time1, double time2, double time3) {
        source = _source;
        destination = _destination;
        timeOptimistic = time1;
        timePesymistic = time2;
        timeAvreg = time3;
        timeEstimated = ((time1 + time2) + (time3 * 4)) / 3;
        show();

    }

    public Przejscie() {
    }

    public void show() {
        System.out.println("Poczatek: " + source);
        System.out.println("Koniec: " + destination);
        System.out.println("optymistyczny czas: " + timeOptimistic);
        System.out.println("pesymistyczny czas: " + timePesymistic);
        System.out.println("najbardziej prawdopodobny: " + timeAvreg);
        System.out.println("Zakładny: " + timeEstimated);
    }
}
