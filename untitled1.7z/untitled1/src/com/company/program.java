package com.company;
import com.company.Klasy.Agregator;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;





public class program {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("ala.txt");
        Agregator agregator = new Agregator(file);
        //System.out.println(word);
    }


}
